import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-complain',
  templateUrl: './view-complain.component.html',
  styleUrls: ['./view-complain.component.scss']
})
export class ViewComplainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
