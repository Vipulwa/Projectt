import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-dashboard',
  templateUrl: './citizen-dashboard.component.html',
  styleUrls: ['./citizen-dashboard.component.scss']
})
export class CitizenDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
