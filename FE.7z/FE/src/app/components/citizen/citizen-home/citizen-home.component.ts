import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-home',
  templateUrl: './citizen-home.component.html',
  styleUrls: ['./citizen-home.component.scss']
})
export class CitizenHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
