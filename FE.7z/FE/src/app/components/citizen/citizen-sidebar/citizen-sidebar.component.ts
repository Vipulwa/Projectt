import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-sidebar',
  templateUrl: './citizen-sidebar.component.html',
  styleUrls: ['./citizen-sidebar.component.scss']
})
export class CitizenSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
