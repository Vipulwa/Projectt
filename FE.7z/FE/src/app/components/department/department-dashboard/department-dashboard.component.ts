import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-dashboard',
  templateUrl: './department-dashboard.component.html',
  styleUrls: ['./department-dashboard.component.scss']
})
export class DepartmentDashboardComponent implements OnInit {

  constructor() {
   
   }

  ngOnInit(): void {
  }
  
}
