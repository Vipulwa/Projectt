import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-sidebar',
  templateUrl: './department-sidebar.component.html',
  styleUrls: ['./department-sidebar.component.scss']
})
export class DepartmentSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
