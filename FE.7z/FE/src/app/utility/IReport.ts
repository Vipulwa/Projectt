import { NumberLiteralType } from "typescript";

export interface IReport{
    month:number;
    complaint:any
}