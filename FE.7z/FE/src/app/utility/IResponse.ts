export interface IResponse{
    status:string,
    message:string,
    result:any

}