export interface IUser{
  otp: string;
    id : number
	username : string
	email : string
	role : string
	status:string
	counter:number
}