package com.cybage.model;

public enum AccountStatus {
	LOCKED,UNLOCKED
}
