package com.cybage.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Feedback;
import com.cybage.service.IFeedbackService;

@RestController
@RequestMapping("/feedback")
public class FeedbackController {

	@Autowired
	IFeedbackService feedbackService;
	
	@PostMapping("/add")
	public ResponseEntity<?> addFeedback(@RequestBody Feedback feedback) {
		try{
			return new ResponseEntity<>(feedbackService.addFeedback(feedback),HttpStatus.CREATED);
		}catch (RuntimeException e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	@GetMapping("get/{username}")
	public ResponseEntity<?> getFeedBack(@PathVariable String username) {
		try{
			return new ResponseEntity<>(feedbackService.getFeedbackByUsername(username),HttpStatus.CREATED);
		}catch (RuntimeException e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	@DeleteMapping("/delete/{username}")
	public ResponseEntity<?> deleteFeedback(@PathVariable String username) {
		try{
			return new ResponseEntity<>(feedbackService.deleteFeedback(username),HttpStatus.CREATED);
		}catch (RuntimeException e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	@GetMapping("/getAll")
	public List<Feedback> getAllFeedback(){
	
			return feedbackService.getAllFeedback();
		
	}
	
	 
	
	

}
