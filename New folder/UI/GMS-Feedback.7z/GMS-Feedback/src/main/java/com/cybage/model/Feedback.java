package com.cybage.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Feedback {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String username;
	@Column
	private LocalDate date;
	@Column
	private String feedback;
	@Column
	private String suggestion;
	
	public Feedback() {
		
	}
	
	public Feedback(int id, String username, LocalDate date, String feedback, String suggestion) {
		super();
		this.id = id;
		this.username = username;
		this.date = date;
		this.feedback = feedback;
		this.suggestion = suggestion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getSuggestion() {
		return suggestion;
	}

	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}

	@Override
	public String toString() {
		return "Feedback [id=" + id + ", username=" + username + ", date=" + date + ", feedback=" + feedback
				+ ", suggestion=" + suggestion + "]";
	}
	
	
	
	
}
