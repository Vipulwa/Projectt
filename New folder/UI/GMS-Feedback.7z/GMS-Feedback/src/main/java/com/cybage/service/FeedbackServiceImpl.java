package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cybage.model.Feedback;
import com.cybage.repository.FeedbackRepository;

@Service
public class FeedbackServiceImpl implements IFeedbackService{

	@Autowired
	FeedbackRepository feedbackRepository;
	
	@Override
	public String addFeedback(Feedback feedback) {
		// TODO Auto-generated method stub
		Feedback result= feedbackRepository.save(feedback);
		return "Successfully Added.";
	}

	@Override
	public Feedback getFeedbackByUsername(String username) {
		// TODO Auto-generated method stub
		
		return feedbackRepository.findByUsername(username);
	}

	@Override
	public String deleteFeedback(String username) {
		// TODO Auto-generated method stub
		 Feedback feedback=feedbackRepository.findByUsername(username);
		 feedbackRepository.delete(feedback);
		 return "Delete Successfully";
	}

	@Override
	public List<Feedback> getAllFeedback() {
		
		List<Feedback>list= feedbackRepository.findAll();
		
			return list;
		
	}

	
}
