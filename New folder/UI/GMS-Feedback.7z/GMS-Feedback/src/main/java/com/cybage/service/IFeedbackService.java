package com.cybage.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cybage.model.Feedback;

public interface IFeedbackService {
	
	public String addFeedback(Feedback feedback);
	
	public Feedback getFeedbackByUsername(String username);

	public String deleteFeedback(String username);
	
	public List<Feedback> getAllFeedback();

}
