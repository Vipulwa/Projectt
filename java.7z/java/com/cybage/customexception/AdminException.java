package com.cybage.customexception;

public class AdminException extends RuntimeException{
	
	public AdminException(String msg) {
		super(msg);
	}

}
