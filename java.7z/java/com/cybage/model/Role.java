package com.cybage.model;

public enum Role {
	ADMIN,CITIZEN,DEPARTMENT
}
