package com.cybage.model;

public enum Status {
	ACTIVE,CLOSED,REMINDER
}
